﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ControlCuGraphicsImagine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            int k = Controls.Count;
            Controls.Add(new UserControl1());
            Controls[k].Left = e.X;
            Controls[k].Top = e.Y;
            Controls[k].Show();

        }
    }
}
